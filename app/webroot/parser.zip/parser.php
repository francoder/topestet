<?
	$res_file = "result.txt";
	if (isset($_GET['clean'])){
		$f = fopen($res_file, "w");
		fclose($f);
	}
	if (isset($_POST['cards'])){
		if (!empty($_FILES['file'])){
			$data = implode("", file($_FILES['file']['tmp_name']));
			$cards_source = explode("---", $data);
		} elseif(!empty($_POST['cards'])){
			$cards_source = $_POST['cards'];
		}
		if (!empty($cards_source)){
			$result_lines = array();
			foreach ($cards_source as $card_source){
				$card = array();
				$lines = explode("\r\n", $card_source);
				$prev_field_name = "";
				foreach ($lines as $line){
					preg_match("/(.+):(.+)/", $line, $result);
					if (!empty($result)){
						$field_name = space_clean($result[1]);
						$field_value = space_clean($result[2]);
						if (!empty($field_value) && strlen($field_value) > 1){
							$card[$field_name] = $field_value;
						}
					} elseif (!empty($prev_field_name)) {
						$line = space_clean($line);
						if (strlen($line) > 1){
							$card[$prev_field_name] .= " ".$line;
						}
					}
					if (!empty($field_name)){
						$prev_field_name = $field_name;
					}
				}
				if (!empty($card)){
					$cards[] = $card;
				}
			}
			$f = fopen($res_file, "w");
			foreach ($cards as $i => $card){
				if (isset($card['Address'])){
					$address = $card['Address'];
					$parties = explode(",", $address);
					$city = explode(" ", $parties[0]);
					$card['address'] = str_replace(" ".$city[count($city) - 1], "", $parties[0]);
					$card['city'] = $city[count($city) - 1];
					$card['state'] = space_clean($parties[1]);
					$country = explode(" ", space_clean($parties[2]));
					$card['zip'] = $country[0];
					$card['country'] = space_clean(str_replace($card['zip']." ", "", $parties[2]));
					unset($card['Address']);
				}
				$result_lines[] = $line = implode("|",$card);
				fwrite($f, $line."\n");
			}
			fclose($f);
		}
	}
?>
<html>
	<head>
		    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
<body>	
	<form method="POST" enctype="multipart/form-data">
		<input type="file" name="file">
		или вставте код:<br>
		<textarea name="cards" style="width:80%;"></textarea><br>
		<?if (!empty($result_lines)):?>
			Результат:<br>
			<textarea style="width:80%; height:400px;"><?=implode("\n", $result_lines)?></textarea><br>
		<?endif;?>
		<input type="submit" value="Загрузить">
	</form>
	<a href="<?=$res_file?>">скачать результат</a>
	<a href="?clean">Очистить файл результатов</a>
</body>
</html>
<?
	function pr($data){
		echo "<pre>";
		print_r($data);
		echo "</pre>";
	}
	
	function space_clean($string){
		preg_replace("/[ ]{2,}/", " ", $string);
		$string = trim($string);
		return $string;
	}
?>